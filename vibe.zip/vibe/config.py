import os


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY") or "bruh"
    WTF_CSRF_ENABLED = True

    PROJECT_PATH = os.path.dirname(os.path.abspath(__file__)) # \...\vibe

    CHROMA_PATH = PROJECT_PATH + "/app/back/chroma_faq_db"
    EXCEL_PATH = PROJECT_PATH + "/_smart_support_vtb_belarus_faq_final.xlsx"
