"""
пример вайбкода ендопинта
# app/main.py
from fastapi import FastAPI
from feedback_handler import process_feedback_and_store

app = FastAPI()

@app.post("/feedback")
def handle_feedback(
    is_relevant: bool,
    question: str,
    answer: str,
    category: str,
    subcategory: str,
    support_specialist_id: str
):
    result = process_feedback_and_store(
        is_relevant=is_relevant,
        question=question,
        answer=answer,
        category=category,
        subcategory=subcategory,
        support_specialist_id=support_specialist_id
    )
    return result
"""

from dotenv import load_dotenv
load_dotenv()

# как жсон для фронта использовать?
import json
import logging
from datetime import datetime
from typing import Dict, Any
import chromadb
import os
import time
from app.back.embedding_client import get_embeddings
from config import Config
from collections import Counter


# Настройка логгера
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(funcName)s:%(lineno)d — %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)
logger = logging.getLogger(__name__)

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
CHROMA_PATH = CURRENT_DIR + "/chroma_faq_db"
COLLECTION_NAME = "t1_vtb_hackton"

# Инициализация клиента Chroma
_client = chromadb.PersistentClient(path=CHROMA_PATH)
_collection = _client.get_collection(COLLECTION_NAME)

"""
Функция process_feedback_and_store, которую мы создали, не предназначена для вызова в основном пайплайне
поиска ответа (rank_faq_templates, get_embeddings, и т.д.).
Когда она должна вызываться?
Только по действию специалиста техподдержки после того, как он увидел результаты поиска и оценил их релевантность.
"""

def get_categories(embeddings: str, top_k_initial=10):
    start_chroma = time.perf_counter()
    client = chromadb.PersistentClient(path=Config.CHROMA_PATH)
    collection = client.get_collection("t1_vtb_hackton")

    chroma_results = collection.query(
        query_embeddings=[embeddings],
        n_results=top_k_initial,
        include=["documents", "metadatas", "distances"]
    )
    chroma_time = time.perf_counter() - start_chroma
    logger.info(f"⏱️ Поиск в ChromaDB завершён за {chroma_time:.2f} сек, найдено {len(chroma_results['documents'][0])} кандидатов")

    # Формируем список всех найденных результатов
    items = []
    for i in range(len(chroma_results["documents"][0])):
        meta = chroma_results["metadatas"][0][i]

        items.append({
            "category": meta["Категория"],
            "subcategory": meta["Подкатегория"]
        })

        logger.info(f"Категория: {meta["Категория"]}, подкатегория: {meta["Подкатегория"]}")

    if not items:
        return None
    
    unique_categories = [item["category"] for item in items]
    unique_subcategories = [item["subcategory"] for item in items]
    unique_cat_counts = Counter(unique_categories)
    unique_subcat_counts = Counter(unique_subcategories)

    cat = max(unique_cat_counts, key=unique_cat_counts.get)
    subcat = max(unique_subcat_counts, key=unique_subcat_counts.get)

    return cat, subcat


def process_feedback_and_store(
        # question: str,
        answer: str
    ) -> Dict[str, Any]:
    """
    Обрабатывает обратную связь от специалиста техподдержки.
    Если is_relevant=False, значит текущий ответ/вопрос не подошёл — добавляем новый FAQ.

    Args:
        is_relevant (bool): True — всё ок, False — нужно добавить новый FAQ.
        question (str): Вопрос (отредактированный).
        answer (str): Ответ (отредактированный).
        support_specialist_id (str): ID специалиста техподдержки.

    Returns:
        Словарь с результатом обработки.
    """
    # logger.info(f"Обработка обратной связи: '{question[:50]}...'")
    logger.info("Добавление нового FAQ в базу")

    # Проверка на пустые строки
    # if not question.strip():
    #     logger.warning("Вопрос пустой — ничего не делаем")
    #     return {"status": "error", "message": "Вопрос не может быть пустым"}
    
    try:
        embedding = get_embeddings(answer)[0]
    except Exception as e:
        logger.error(f"Ошибка получения эмбеддинга: {e}")
        return {"status": "error", "message": "Ошибка при генерации эмбеддинга"}
    
    category, subcategory = get_categories(embedding)
    logger.info(f"Результат классификации фидбека: \n Категория '{category}'; подкатегория '{subcategory}'")
    
    # Подготовка метаданных
    metadata = {
        "Шаблонный ответ": answer,
        "Категория": category,
        "Подкатегория": subcategory
    }

    # Генерация уникального ID
    new_id = f"feedback_{int(datetime.now().timestamp())}"

    try:
        _collection.add(
            ids=[new_id],
            embeddings=[embedding],
            # documents=[question],
            metadatas=[metadata]
        )
        logger.info(f"Новый FAQ добавлен в базу: ID {new_id}")
        return {
            "status": "added",
            # "message": f'Новый вопрос "{question[:50]}..." добавлен в базу знаний',
            "id": new_id
        }
    except Exception as e:
        logger.error(f"Ошибка при добавлении в ChromaDB: {e}")
        return {"status": "error", "message": "Ошибка при добавлении в базу"}
    

# # Пример: специалист говорит "не релевантно" - добавляем новый FAQ
# result = process_feedback_and_store(
#     is_relevant=False,
#     question="Как открыть счёт в долларах?",
#     answer="Счёт открывается в мобильном приложении за 5 минут.",
#     category="Счета",
#     subcategory="Открытие",
#     support_specialist_id="support_001"
# )
# print(result)
# # {"status": "added", "message": 'Новый вопрос "Как открыть счёт в долларах?..." добавлен в базу знаний', "id": "feedback_..."}

# # Пример: специалист говорит "релевантно" - ничего не делаем
# result = process_feedback_and_store(
#     is_relevant=True,
#     question="Как подключить интернет-банк?",
#     answer="Откройте приложение и нажмите 'Подключить'.",
#     category="Интернет-банк",
#     subcategory="Подключение",
#     support_specialist_id="support_002"
# )
# print(result)
# # {"status": "relevant", "message": "Вопрос релевантен, ничего не добавлено."}