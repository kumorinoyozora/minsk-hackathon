import json

def extract_category_from_classifier(classifier_output: dict) -> tuple[str, str]:
    """
    Извлекает категорию и подкатегорию из ответа классификатора.
    Ожидается, что content содержит JSON вида:
    {"category": "...", "subcategory": "..."}

    Поддерживает обёртку в ```json ... ```
    """
    content = classifier_output["choices"][0]["message"]["content"].strip()

    # Удаляем markdown-обёртку, если есть
    if content.startswith("```"):
        # Убираем первую и последнюю строку с ```
        lines = content.splitlines()
        if lines[0].strip().startswith("```"):
            content = "\n".join(lines[1:-1]) if len(lines) > 2 else lines[0].strip("`")

    try:
        data = json.loads(content)
        return data["category"], data["subcategory"]
    except (json.JSONDecodeError, KeyError) as e:
        raise ValueError(f"Не удалось извлечь категорию из ответа классификатора: {content}") from e