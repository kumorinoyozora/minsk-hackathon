import logging
import time
import pandas as pd
import chromadb
# from app.back.embedding_client import get_embeddings
from embedding_client import get_embeddings
import os
# from config import Config

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)
logger = logging.getLogger(__name__)

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__)) 
EXCEL_PATH = CURRENT_DIR + "/_smart_support_vtb_belarus_faq_final.xlsx"
CHROMA_PATH = CURRENT_DIR + "/chroma_faq_db"
COLLECTION_NAME = "t1_vtb_hackton"
BATCH_SIZE = 32 

def main():
    start_time = time.perf_counter()
    # === 1. Подготовка данных ===
    df = pd.read_excel(EXCEL_PATH)
    df["id"] = [f"faq_{i}" for i in range(len(df))]
    ids = df["id"].tolist()
    documents = df["Пример вопроса"].fillna("").tolist()

    metadatas = []
    for _, row in df.iterrows():
        metadatas.append({
            "Категория": str(row["Основная категория"]) if pd.notna(row["Основная категория"]) else "",
            "Подкатегория": str(row["Подкатегория"]) if pd.notna(row["Подкатегория"]) else "",
            "Приоритет": str(row["Приоритет"]) if pd.notna(row["Приоритет"]) else "",
            "Шаблонный ответ": str(row["Шаблонный ответ"]) if pd.notna(row["Шаблонный ответ"]) else ""
        })


    # === 2. Инициализация ChromaDB ===
    logger.info(f"Инициализация ChromaDB (путь: {CHROMA_PATH})")
    client = chromadb.PersistentClient(path=CHROMA_PATH)
    collection = client.get_or_create_collection(
        name="t1_vtb_hackton",
        # настройка индекса приближённого поиска (ANN). HNSW для быстрого поиска ближайших соседей.
        metadata={"hnsw:space": "cosine"}
    )

    # === 3. Пакетная загрузка ===
    logger.info(f"📤 Загрузка данных пакетами по {BATCH_SIZE} записей...")
    total = len(documents)

    for i in range(0, total, BATCH_SIZE):
        end_idx = min(i + BATCH_SIZE, total)
        batch_ids = ids[i:end_idx]
        batch_docs = documents[i:end_idx]
        batch_meta = metadatas[i:end_idx]

        logger.info(f"→ Пакет {i // BATCH_SIZE + 1}: строки {i}–{end_idx - 1}")

        batch_embeddings = get_embeddings(batch_docs)

        collection.add(
            ids=batch_ids,
            embeddings=batch_embeddings,
            documents=batch_docs,
            metadatas=batch_meta
        )

    # === Завершение ===
    elapsed = time.perf_counter() - start_time
    logger.info(f"Успешно загружено {total} записей в коллекцию '{COLLECTION_NAME}'")
    logger.info(f"Общее время выполнения: {elapsed:.2f} секунд ({elapsed / 60:.2f} мин)")

if __name__ == "__main__":
    main()