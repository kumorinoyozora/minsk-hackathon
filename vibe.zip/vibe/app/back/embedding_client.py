import os
import time
import logging
from typing import Union, List
from openai import OpenAI
from dotenv import load_dotenv

# Настройка логгера
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(funcName)s:%(lineno)d — %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)
logger = logging.getLogger(__name__)

# Загружаем переменные окружения из .env
load_dotenv()

# Конфигурация
API_KEY = os.getenv("LITELLM_API_KEY")
if not API_KEY:
    raise RuntimeError("LITELLM_API_KEY не задан в .env")

BASE_URL = "https://llm.t1v.scibox.tech/v1"

def get_embeddings(texts: str | List[str], model: str = "bge-m3") -> List[List[float]]:
    if isinstance(texts, str):
        texts = [texts]

    logger.info(f"Отправка запроса на эмбеддинги для {len(texts)} текст(ов). Пример: {texts[0][:50]}...")
    start_time = time.perf_counter()

    try:
        client = OpenAI(api_key=API_KEY, base_url=BASE_URL)
        resp = client.embeddings.create(model=model, input=texts)
        embeddings = [emb.embedding for emb in resp.data]

        elapsed = time.perf_counter() - start_time
        logger.info(f"Получено {len(embeddings)} эмбеддингов за {elapsed:.2f} сек")

        return embeddings
    except Exception as e:
        elapsed = time.perf_counter() - start_time
        logger.error(f"Ошибка при получении эмбеддингов за {elapsed:.2f} сек: {e}")
        raise

# --- Проверка работоспособности при запуске напрямую ---
if __name__ == "__main__":
    print("🧪 Тестирование функции get_embeddings...\n")

    try:
        test_text = "Это тестовый запрос для проверки эмбеддингов."
        embeddings = get_embeddings(test_text)

        print(f"✅ Успешно получены эмбеддинги!")
        print(f"Количество текстов: {len(embeddings)}")
        print(f"Длина вектора: {len(embeddings[0])}")
        print(f"Первые 5 значений: {[round(x, 5) for x in embeddings[0][:5]]}")

    except Exception as e:
        print(f"❌ Ошибка при вызове API: {e}")
        print("\n💡 Проверьте:")
        print("- Наличие и правильность .env файла")
        print("- Доступность сервера: https://llm.t1v.scibox.tech/v1/models")
        print("- Валидность токена (попробуйте через curl)")