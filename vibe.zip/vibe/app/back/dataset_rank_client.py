import chromadb
import os
import time
import logging
from dotenv import load_dotenv
from app.back.embedding_client import get_embeddings
from app.back.classify_question_with_qwen import classify_question_with_qwen
from app.back.classifier_extractor import extract_category_from_classifier
from app.back.chroma_db_dataset import main
from config import Config


load_dotenv()

# Настройка логгера
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(funcName)s:%(lineno)d — %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)
logger = logging.getLogger(__name__)


def rank_faq_templates(
    user_query: str,
    top_k_initial: int = 5
    ) -> dict | None:
    """
    Основная функция модуля ранжирования: возвращает ТОЛЬКО ОДИН лучший FAQ-ответ
    на основе сценариев и расстояния, с использованием классификатора.

    Args:
        user_query (str): Вопрос от клиента.
        top_k_initial (int): Сколько кандидатов взять из ChromaDB.

    Returns:
        Словарь с ключами:
        - id, question, answer, category, subcategory, priority,
        - original_distance
        Или None, если ничего не найдено.
    """

    start_total = time.perf_counter()
    logger.info(f"Начало обработки запроса: '{user_query[:60]}...'")

    api_key = os.getenv("LITELLM_API_KEY")
    if not api_key:
        raise ValueError("Переменная LITELLM_API_KEY не найдена в .env")
    
    # Получение эмбеддинга 
    start_emb = time.perf_counter()
    query_embedding = get_embeddings(user_query)[0]
    emb_time = time.perf_counter() - start_emb
    logger.info(f"⏱️ Эмбеддинг получен за {emb_time:.2f} сек")
    

    # Поиск в ChromaDB
    start_chroma = time.perf_counter()
    client = chromadb.PersistentClient(path=Config.CHROMA_PATH)
    try:
        collection = client.get_collection("t1_vtb_hackton")
    except Exception as e:
        main() # создание бд


    chroma_results = collection.query(
        query_embeddings=[query_embedding],
        n_results=top_k_initial,
        include=["documents", "metadatas", "distances"]
    )
    chroma_time = time.perf_counter() - start_chroma
    logger.info(f"⏱️ Поиск в ChromaDB завершён за {chroma_time:.2f} сек, найдено {len(chroma_results['documents'][0])} кандидатов")

    # Формируем список всех найденных результатов
    items = []
    for i in range(len(chroma_results["documents"][0])):
        faq_id = chroma_results["ids"][0][i]
        meta = chroma_results["metadatas"][0][i]
        dist = chroma_results["distances"][0][i]
        doc = chroma_results["documents"][0][i]

        items.append({
            "id": faq_id,
            "question": doc,
            "answer": meta["Шаблонный ответ"],
            "category": meta["Категория"],
            "subcategory": meta["Подкатегория"],
            "priority": meta["Приоритет"],
            "original_distance": dist
        })

        logger.info(f"Категория: {meta["Категория"]}, подкатегория: {meta["Подкатегория"]}")

    if not items:
        return None

    # Проверяем: все ли результаты из одной категории и подкатегории?
    unique_categories = {item["category"] for item in items}
    unique_subcategories = {item["subcategory"] for item in items}

    # Если только одна категория и одна подкатегория — возвращаем ближайший
    if len(unique_categories) == 1 and len(unique_subcategories) == 1:
        best_item = min(items, key=lambda x: x["original_distance"])
        total_time = time.perf_counter() - start_total
        logger.info(f"⏱️ Единая категория/подкатегория - выбран ближайший вектор. Общее время: {total_time:.2f} сек")
        return best_item

    # Если категории/подкатегории различаются — используем Qwen
    logger.info("Категории различаются — запуск классификации через Qwen...")
    start_qwen = time.perf_counter()
    try:
        # Классифицируем вопрос через Qwen
        classifier_output = classify_question_with_qwen(user_query, api_key=api_key)
        qwen_time = time.perf_counter() - start_qwen
        logger.info(f"⏱️ Qwen вернул результат за {qwen_time:.2f} сек")

        # Извлекаем предсказанную категорию и подкатегорию через ваш модуль
        predicted_category, predicted_subcategory = extract_category_from_classifier(classifier_output)
        logger.info(f"Предсказано: Категория='{predicted_category}', Подкатегория='{predicted_subcategory}'")

        # Фильтруем по предсказанию
        filtered_items = [
            item for item in items
            if item["category"] == predicted_category and item["subcategory"] == predicted_subcategory
        ]

        # Если есть совпадения — возвращаем ближайший из них
        if filtered_items:
            best_item = min(filtered_items, key=lambda x: x["original_distance"])
            return best_item

        # Если нет совпадений — fallback: возвращаем ближайший из всех
        if filtered_items:
            best_item = min(filtered_items, key=lambda x: x["original_distance"])
            total_time = time.perf_counter() - start_total
            logger.info(f"⏱️ Совпадение с предсказанием Qwen → выбран ближайший. Общее время: {total_time:.2f} сек")
            return best_item
        else:
            logger.warning("Нет FAQ в предсказанной категории — fallback на ближайший")

    except Exception as e:
        qwen_time = time.perf_counter() - start_qwen
        logger.error(f"Ошибка при вызове Qwen за {qwen_time:.2f} сек: {e}")

    # === Fallback: ближайший из всех ===
    best_item = min(items, key=lambda x: x["original_distance"])
    total_time = time.perf_counter() - start_total
    logger.info(f"⏱️ Fallback на ближайший результат. Общее время: {total_time:.2f} сек")
    logger.info(f"Категория: {best_item["category"]}, подкатегория: {best_item["subcategory"]}")
    return best_item