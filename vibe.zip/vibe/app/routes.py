from flask import render_template, request, jsonify
from flask_socketio import emit, join_room
from app.back.dataset_rank_client import rank_faq_templates
from app import app, socketio
from app.back.feedback_handler import process_feedback_and_store


chat_messages = list()


@app.route("/")
def index():
    # При загрузке страницы можно передавать роль через query string (?role=user или ?role=operator)
    role = request.args.get("role", "user")
    return render_template("chat.html", role=role, messages=chat_messages)


@socketio.on("join")
def handle_join(data):
    role = data.get("role", "user")
    join_room("support_chat")
    emit("status", {"msg": f"{role} присоединился к чату."}, room="support_chat")


@socketio.on("send_message")
def handle_message(data):
    msg = {"role": data["role"], "text": data["text"]}
    chat_messages.append(msg)
    emit("new_message", msg, room="support_chat")

    # если сообщение от пользователя — запускаем внутреннюю обработку
    if data["role"] == "user":
        # threading.Thread(target=process_user_request, args=(data["text"],)).start()
        process_user_request(data["text"])


def process_user_request(user_text):
    processing_res = rank_faq_templates(user_text)
    result = {
        "text_suggestions": [
            processing_res["answer"],
        ],
        "category": processing_res["category"],
        "subcategory": processing_res["subcategory"],
        "meta": {"length": len(user_text)},
    }

    socketio.emit("backend_result", result, room="support_chat")

@socketio.on("send_feedback")
def handle_feedback(data):
    message = data.get("message")
    backend_result_id = data.get("backend_result_id")
    
    process_feedback_and_store(message)

if __name__ == "__main__":
    socketio.run(app, host="0.0.0.0", port=5000)

# http://localhost:5000/?role=operator
# http://localhost:5000/?role=user
